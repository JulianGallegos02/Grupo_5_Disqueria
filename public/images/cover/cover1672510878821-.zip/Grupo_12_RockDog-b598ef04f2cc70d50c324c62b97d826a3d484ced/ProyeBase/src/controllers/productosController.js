//------------- Validaciones----------------------------------
const {check,validationResult,body} = require("express-validator");
const path = require("path");
const {unlink}= require("fs-extra")
//------------- punto. MIL -----------------------------------
const divisorNumerico = n => n.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
const db = require("../database/models");
const sequelize = db.sequelize;

//-------------controladores----------------------------------
module.exports={
    //-----Productos---

    guardarProducto :async (req,res)=>{
        let errors = validationResult(req);
        if(errors.isEmpty()){
            
                const producto =  await db.Producto.create({
                    nombre_producto : req.body.nombreProducto,
                    descripcion:req.body.descripcion,
                    detalle : req.body.detalle,
                    imagen: req.file.filename,
                    estado : 0,
                    precio : req.body.precioProducto,
                    stock: req.body.stock,
                    FK_marca:req.body.marca
                });
                let idCategoria = req.body.categorias
                const categoriaprod =  await db.Categoria.findByPk(idCategoria)
                
                producto.addCategoria(categoriaprod)

                .then(result=>{
                    res.redirect("/")
                })
        }else{
            let nuevoProducto = {
                nombreProducto:req.body.nombreProducto,
                descripcion : req.body.descripcion,
                colorPeso : req.body.colorPeso,
                precioProducto : req.body.precioProducto,
                categoria : req.body.categorias,
                marca : req.body.marca,
            }

            console.log(errors)
        unlink(req.file.path)
        return res.render("crearProducto", {nuevoProducto,errors: errors.errors})
        }
        
    },
    guardarEdiciones: (req, res) => {

        if(req.file != undefined){
            unlink(path.resolve(path.join(__dirname,"../../public/images/productos/",req.body.oldImagen)))
        }

            const producto = {
                nombre_producto : req.body.nombreProducto,
                descripcion:req.body.descripcion,
                detalle : req.body.detalle,
                imagen: req.file ? req.file.filename : req.body.oldImagen,
                estado : 0,
                precio : req.body.precioProducto,
                stock: req.body.stock,
                FK_marca:req.body.marca
            };

            const subidaProd = db.Producto.update(producto,{where:{id:req.params.id}})
            const updateCategoria = db.Categoria_Producto.update({ID_categoria :req.body.categorias},{where:{id:req.params.id}})
            Promise.all([subidaProd,updateCategoria])
            .then(result =>{
                res.redirect("/")
            })
    },    
    borrarProducto: (req, res) => {
        db.Producto.update({estado :1 },{where:{id:req.params.id}})
        .then(()=>{
            res.redirect("/")
        })
    },

}

