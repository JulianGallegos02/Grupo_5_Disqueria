# Grupo_12_RockDog 

--------------------------------------------------------------------------------------------------------------------------------------------------
Quienes Somos?

Nosotros somos RockDog, y queremos darles acceso a nuestra tienda digital.
Esperamos que sea de su agrado!

--------------------------------------------------------------------------------------------------------------------------------------------------
Integrantes del Grupo 

- Lucas Bianco: 
Hola! Me llamo Lucas Bianco, Tengo 26 años,Soy de mar del plata, Pero actualmente vivo en CABA, trabajo en el area tecnica de una escuela privada llamada ORT, si tengo que describirme en pocas palabras seria obsesivo y detallista, despues de muchos idas y vueltas (primer año de ingeniero en sistemas, primer año de analista en sistemas y un largo etc ) por fin me puse a programar y logre la constancia que estaba buscando, el trabajo en grupo no suele ser mi especialidad, puesto que estoy acostumbrado a trabajar solo, asi que este va a ser uno de los mayores desafios del curso, Por suerte con los compañeros que me tocaron somos lo que se dice complementarios, Lo que no sabe uno el otro puede cubrir tranquilamente eso, Asi que eso ayuda bastante! 


- Nay Da Rosa: Soy Nay. Tengo conocimientos previos de programación muy escasos. Soy muy perfeccionista pero sé respetar y escuchar lo que todos tengan para aportar. Me involucré un par de veces en proyectos relacionados con el marketing, pero nada muy profesional. Previamente estudié inglés (por seis años), el año pasado terminé la secundaria y me gusta todo lo relacionado con lo artistico (dibujo, musica, baile).


--------------------------------------------------------------------------------------------------------------------------------------------------

 Objetivos


 Queremos crear un sitio donde los clientes encuentren rapido lo que buscan y en el caso de no encontralo que el dinamismo de la misma los invite a explorar las diferentes categorias con las que cuenta la pagina.
 
 En pocas palabras una pagina simple, visible y agil, que invite a ser explorada.

--------------------------------------------------------------------------------------------------------------------------------------------------

Referencias que nos inspiran

    -https://www.kiwoko.com/
    Tiene un carrito de compras muy dinámico y es esteticamente agradable. 
    En el detalle de producto se puede modificar segun el requerimiento del
    comprador ya sea color del producto o el peso del mismo.

    -https://www.sbs.com.ar/ 
    Es una pagina facil de usar, donde el encabezado se mantiene
    fijo y es una de las cosas que nos parecen utiles y queremos 
    incorporar a nuestro proyecto. El carrito de compras tambien
    se muestra constantemente.
    En su version mobile tomamos tambien la simpleza del diseño 
    y la posibilidad de acceder rapido a lo que estamos buscando.

    -https://www.bookdepository.com/ 
    Tomamos de esta pagina de venta de libros internacional
    las distintas opciones de busqueda, la barra lateral 
    derecha donde tienen opciones de busqueda directa.
    La version mobile es un buen resumen de la version desktop, 
    si bien los filtros de busqueda son distintos la barra de
    'busqueda' es lo primero que se ve. 

    - https://www.betterworldbooks.com/ 
    Es muy similar a las anteriores, su version mobile 
    es 'pobre' no da tantas opciones de busqueda por categoria.

    - https://www.planetadelibros.com/
    Tiene un formato particular de busqueda, un menu de 
    opciones dispuestos en lista que cuando bajas se
    deja de ver y se transforma en un menu desplegable.
    La tomamos para ver distintas opciones.

    -https://www.bookin-libros.com/ 
    Esta pagina es mas "simple" que las otras, muestra
    menos productos a los que solo podes acceder buscando
    por categoria con menu desplegable cada una.
    Su version mobile es mejor que la version desktop.
    

