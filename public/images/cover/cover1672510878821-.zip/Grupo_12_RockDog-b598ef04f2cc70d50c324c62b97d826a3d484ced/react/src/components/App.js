import React from 'react';
import '../App.css';
import SideBar from './SideBar';
import ComponentWrapper from './ComponentWrapper';
function App() {
  return (
    <React.Fragment>
      
      <div id="wrapper">
        <SideBar />
        <ComponentWrapper />
      </div>
    </React.Fragment>
  );
}

export default App;
