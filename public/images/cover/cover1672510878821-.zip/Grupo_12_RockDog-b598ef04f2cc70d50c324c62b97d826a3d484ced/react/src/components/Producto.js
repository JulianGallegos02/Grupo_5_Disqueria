import React from "react";

function Producto(props) {
    return(
        <React.Fragment>
            <div>
                <h2>{props.nombre}</h2>
                <p>Precio: {props.precio}</p>
                <ul>
                    {
                        props.items.map(producto => <li>{producto}</li>)
                    }
                </ul>
            </div>
        </React.Fragment>
    );
}

export default Producto;