import React from "react";
import Producto from "./Producto";

const item = ["sa","sa2","sa3"]
function TiraProductos() {
    return(
        <React.Fragment>
        <div>
            <Producto nombre="Comida" precio="100" items = {item}/>

        </div>
        </React.Fragment>
    );
};

export default TiraProductos;