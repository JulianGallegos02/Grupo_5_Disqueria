import React from "react";
import TopBar from "./TopBar";
import Footer from "./Footer";
import TiraProductos from "./TiraProductos";

function ContentWrapped() {
  return (
    <React.Fragment>
      <div id="content-wrapper" className="d-flex flex-column">
        <div id="content">
          <TopBar />
          <TiraProductos />
        </div>

      <Footer />
      </div>

    </React.Fragment>
  );
}

export default ContentWrapped;