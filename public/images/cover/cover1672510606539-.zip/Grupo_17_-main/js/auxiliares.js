module.exports = {
    textoSeguro : (texto)=>{
       const str = texto;
        return str;
    }
}