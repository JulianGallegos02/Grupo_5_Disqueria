# Retrospectiva Grupo 17 (Sprint 7) # 

## COMENZAR A HACER ##

- Terminar las tareas con mas tiempo de sobra
- Me gustaria una call Grupal a la semana (Marian)

## HACER MAS ##

- Mejor comunicacion grupal
- Intercambiar ideas de codigo
- Avisar al grupo si se esta trabado en una tarea
- Avisar de los push y pull
- Pendientes

## CONTINUAR HACIENDO ##
- Mantener actualizado el tablero de trabajo
- Mantener el repositorio actualizado
- trabajar en equipo

## HACER MENOS ##
- No avisar cuando no se llega con su parte del trabajo.

## DEJAR DE HACER ##
- Dejar tareas para ultimo momento

# Retrospectiva Grupo 17 (Sprint 6) # 

## COMENZAR A HACER ##

- Terminar las tareas a tiempo

## HACER MAS ##

- Mejor comunicacion grupal
- Avisar al grupo si se esta trabado en una tarea
- 16:34 GOL DE ARGENTINA A PAISES BAJOS

## CONTINUAR HACIENDO ##
- Mantener actualizado el tablero de trabajo
- Mantener el repositorio actualizado

## HACER MENOS ##
- No avisar cuando no se llega con su parte del trabajo.

## DEJAR DE HACER ##
- Dejar tareas para ultimo momento

# Retrospectiva Grupo 17 (Sprint 5) # 

## COMENZAR A HACER ##

- Terminar las tareas a tiempo

## HACER MAS ##

- Mejor comunicacion grupal
- Avisar al grupo si se esta trabado en una tarea

## CONTINUAR HACIENDO ##
- Mantener actualizado el tablero de trabajo
- Mantener el repositorio actualizado

## HACER MENOS ##
- No avisar cuando no se llega con su parte del trabajo

## DEJAR DE HACER ##
- Dejar tareas para ultimo momento


# Retrospectiva Grupo 17 (Sprint 4) # 

## COMENZAR A HACER ##

- Tareas mejor detalladas en tablero

## HACER MAS ##
- Reuniones semanales


## CONTINUAR HACIENDO ##
- Mantener actualizado el tablero de trabajo
- Mantener el repositorio actualizado
- Comunicación fluida por discord y wtsp
- Programar en equipo cuando uno se traba


## HACER MENOS ##
- Definir las reuniones muy sobre la hora

## DEJAR DE HACER ##
- Llegar con los entregables a ultimo momento

# Retrospectiva Grupo 17 (Sprint 3) # 

## COMENZAR A HACER ##

- Organizarnos mejor a la hora de reunirnos
- Avisar por que parte esta de su tarea asignada para no atrasar al resto.
- Coordinar reuniones para ponernos de acuerdo sobre los lineamientos generales.


## HACER MAS ##
- Que Discord sea el canal principal para tener todo el seguimiento del proyecto en un solo lugar.
- Repasar y tratar de no quedarse atras.
- Coordinar reuniones para ponernos de acuerdo sobre los lineamientos generales.


## CONTINUAR HACIENDO ##
- Mantener actualizado el tablero de trabajo
- Mantener el repositorio actualizado


## HACER MENOS ##
- No Contestar a tiempo los mensajes del discord
- Correr a ultimo momento para llegar con un entregable
- Comunicar poco las cosas que hago


## DEJAR DE HACER ##
- Organizar reuniones a ultimo momento
- Cambiar horarios de reuniones que ya estaban establecidos
- Contestar tarde los mensajes

# Retrospectiva Grupo 17 (Sprint 2) # 

## COMENZAR A HACER ##

- Organizarnos mejor a la hora de reunirnos
- Avisar por que parte esta de su tarea asignada para no atrasar al resto.
- Coordinar reuniones para ponernos de acuerdo sobre los lineamientos generales.


## HACER MAS ##
- Que Discord sea el canal principal para tener todo el seguimiento del proyecto en un solo lugar.
- Repasar y tratar de no quedarse atras


## CONTINUAR HACIENDO ##
- Mantener actualizado el tablero de trabajo
- Mantener el repositorio actualizado


## HACER MENOS ##
- No Contestar a tiempo los mensajes del discord
- Correr a ultimo momento para llegar con un entregable
- No responder el discord en tiempo y forma para que la organizacion sea fluida
- Comunicar poco las cosas que hago


## DEJAR DE HACER ##
- Organizar reuniones a ultimo momento
- Cambiar horarios de reuniones que ya estaban establecidos
- Contestar tarde los mensajes



# Retrospectiva Grupo 17 (Sprint 1) # 

## COMENZAR A HACER ##

- Definir de antemano el tema de las reuniones
- Optimizar la duracion de las reuniones
- Implementar y mantener actualizado el tablero de trabajo
- Que la organizacion sea mas fluida para poder concretar cada sprint de manera segura
- Cada uno avise por que parte esta de su tarea asignada , asi no nos atrasamos
- Reunion unos dias antes de la entrega para poder ver cuanto nos falta o si ya esta el trabajo terminado
- Explicar de forma mas clara y detallada posible lo hecho por cada uno
- Ordenar el código para que sea legible para el otro

## HACER MAS ##

- Consensuar las decisiones y una vez aprobado no volver sobre los mismos temas
- Usar Discord como canal principal para tener todo el seguimiento del proyecto en un solo lugar
- Mantener informado al equipo sobre desvios en lo planificado para poder buscar una alternativa lo antes posible
- Que Discord sea el canal principal para tener todo el seguimiento del proyecto en un solo lugar.
- Coordinar reuniones para ponernos de acuerdo sobre los lineamientos generales

## CONTINUAR HACIENDO ##

- Llegar con la fecha de entrega
- Mantener el repositorio actualizado
- Mantener el tablero de trabajo actualizado
- Repasar y tratar de no quedarse atras
- Consultar acerca de decisiones que sean cruciales sobre la pagina

## HACER MENOS ##

- No Contestar a tiempo los mensajes del discord
- Correr a ultimo momento para llegar con un entregable
- No responder el discord en tiempo y forma para que la organizacion sea fluida
- Comunicar poco las cosas que hago

## DEJAR DE HACER ##

- Organizar reuniones a ultimo momento
- Cambiar horarios de reuniones que ya estaban establecidos
- Contestar tarde los mensajes



