# Proyecto Integrador Grupo 17: Sucré Pasteleria #       
## Descripcion del Proyecto ##
El objetivo de nuestra página es exhibir todos nuestros productos de manera cómoda y funcional para el cliente, y ofrecerle el mejor acompañamiento a la hora del te. Nuestra página también cuenta con servicio de cadetería para que, que unos cuantos clicks, el cliente pueda recibir estas tentadores delicias en su hogar, facilitando la realización de su compra.
 
## Publico Objetivo ##
Nuestro publico objetivo son aquellos golosos que quieran disfrutar de unas ricas tortas desde la comodidad de su casa.

## Integrantes del Proyecto ##
#### Andrea Carello ####
> Me llamo Andrea Carello, tengo 37 años, soy de Florida Vicente Lopez y estudie Ingenieria en Sistemas en la UTN Regional Delta.
#### Facundo Joel Morcillo ####
> Me llamo Facundo Joel Morcillo , tengo 22 años , soy de Buenos Aires,  Quilmes Oeste , y estudio
Licenciatura en informatica en la Universidad de Quilmes. Tengo conocimiento con lenguajes como Python , C , html y CSS.
#### Mariano Macias ####
> Me llamo Mariano Macias, tengo 32 años, soy de Buenos Aires, ejecutivo de cuentas por varios años, estudiante de sistemas en UTN y afan de la tecnologia.

## Paginas de referencia ##

- https://dulcecharlottetienda.com.ar/

- https://www.mauricioasta.com/

- https://www.valuramallo.com/

- http://alotiendaycafe.com.ar/

- https://www.violetamassey.com.ar/

## Paleta de Colores ##

- #F4ECE0
- #FCDEC0
- #7D5A50
- #FFFFFF

## Tipografia ##

- Playfair Display

## Tablero de Trabajo ##

- https://trello.com/b/PaFQh2o5/proyecto-e-comerce

## Repositorios ##

### Proyecto node ###

- https://github.com/AndyCarello/Grupo_17_
### Proyecto react ###

- https://github.com/AndyCarello/Grupo_17_Dashboard_Sprint8







